import json

PATH = 'text_5700_test/data.json'


with open(PATH) as f:
    data = json.load(f)

print('FOR DEBUG')

audio_clip_name = list(data.keys())[0] # MUL0001 


goal = data[audio_clip_name]['goal']
log = data[audio_clip_name]['log']

# PRINTING THE CONVERSATION
for i in data[audio_clip_name]['log']:
    print(f"{i['tag']} : {i['text']}", i['dialog_act'])
    print(i['dialog_act'], i['metadata'], i['span_info'], '\n')   # dialog_act', 'metadata', 'span_info', 'tag', 'text', 'words'



""" The dialogue state for each dialogue is recorded in the "metadata" field in every turn the 
    same as MultiWOZ 2.1. The state have two sections: semi, book. Semi refers to slots from a particular domain.
     Book refers to booking slots for a particular domain. The joint accuracy metrics includes ALL slots."""